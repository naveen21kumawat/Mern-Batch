import React from 'react'

function Login() {
  return (
    <>
    <input ></input>
    </>
  )
}

export default Login