import React from 'react'

function Home() {
  return (
    <>
      <div style={{ textAlign: 'center', marginTop: '50px' }}>
        <h1>Welcome to Task Manager</h1>
        <p>This is your simple home page.</p>
        <button>Get Started</button>
      </div>
    </>
  )
}

export default Home